function [node_loc,X,Y,Z,dispdata] = read_disp_mat(fname)

% function [node_loc,X,Y,Z] = read_disp_mat(fname);
%
% read_disp_mat reads a .mat file that contains information about node IDS and
% their x,y,z locations and associatd displacements and returns 5 3D matrices
%
% node_loc is matrix of node numbers
% X,Y,Z are matrices of X, Y, and Z node locations (initial)
% dispdata is matrix of z-displacement
%
%
%

load(fname,'displacements','axialmm','elevmm','latmm','tms')

X=repmat(elevmm',[1,length(latmm),length(axialmm)])/10;
Y=repmat(latmm,[length(elevmm),1,length(axialmm)])/10;
Z=-repmat(reshape(axialmm, [1 1 length(axialmm)]),[length(elevmm),length(latmm),1])/10;

node_loc=1:numel(X);
node_loc=reshape(node_loc,size(X));

dispdatam=displacements*10^-6; % m

dispdata=-dispdatam*100; % convert to cm and make negative (-z displacement)

end
