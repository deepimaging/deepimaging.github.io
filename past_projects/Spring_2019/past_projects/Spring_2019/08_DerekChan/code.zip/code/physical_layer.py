import tensorflow as tf
import numpy as np
import h5py
import scipy.io
import time

tf.reset_default_graph()

# Load data
filename = '/work/dyc6/dispnn/iq_data_shallow.h5'
f = h5py.File(filename, 'r')

train_dataset = tf.data.Dataset.from_tensor_slices((f['train_images'], f['train_labels']))
validation_dataset = tf.data.Dataset.from_tensor_slices((f['validation_images'], f['validation_labels']))
test_dataset = tf.data.Dataset.from_tensor_slices((f['test_images'], f['test_labels']))

batched_train = train_dataset.shuffle(27000).repeat().batch(75)
batched_validation = validation_dataset.shuffle(3000).repeat().batch(75)
batched_test = test_dataset.shuffle(3000).repeat().batch(75)

train_iterator = batched_train.make_initializable_iterator()
validation_iterator = batched_validation.make_initializable_iterator()
test_iterator = batched_test.make_initializable_iterator()

next_train = train_iterator.get_next()
next_validation = validation_iterator.get_next()
next_test = test_iterator.get_next()

# Placeholders
x = tf.placeholder(tf.float32, [None, 1200, 2, 2])
y_ = tf.placeholder(tf.float32, [None, 1200])

# CNN
init = tf.contrib.layers.variance_scaling_initializer()

pl_weights = tf.get_variable(name='pl_weights', shape=(1, 1200, 1, 1), dtype=tf.float32, initializer=tf.initializers.random_normal(stddev=1.0), trainable=True)
pl_weights_norm = tf.nn.sigmoid(pl_weights)
pl_weights_round = tf.minimum(1e20*tf.maximum(pl_weights_norm-0.499,0), 1)
pl_weights_tile = tf.tile(pl_weights_round, tf.constant([1, 1, 2, 2]))

input_multiply = tf.multiply(x, pl_weights_tile)

conv1 = tf.layers.conv2d(input_multiply, 64, [3, 3], padding='same', activation=tf.nn.relu, kernel_initializer=init, name='conv1')
pool1 = tf.layers.max_pooling2d(conv1, [2, 1], [2, 1], padding='same', name='pool1')

conv2 = tf.layers.conv2d(pool1, 128, [3, 3], padding='same', activation=tf.nn.relu, kernel_initializer=init, name='conv2')
pool2 = tf.layers.max_pooling2d(conv2, [2, 1], [2, 1], padding='same', name='pool2')

conv3 = tf.layers.conv2d(pool2, 256, [3, 3], padding='same', activation=tf.nn.relu, kernel_initializer=init, name='conv3')
pool3 = tf.layers.max_pooling2d(conv3, [2, 1], [2, 1], padding='same', name='pool3')

conv4 = tf.layers.conv2d(pool3, 512, [3, 3], padding='same', activation=tf.nn.relu, kernel_initializer=init, name='conv4')

conv5 = tf.layers.conv2d_transpose(conv4, 256, [2, 1], [2, 1], padding='same', activation=tf.nn.relu, kernel_initializer=init, name='conv5')

conv6 = tf.layers.conv2d_transpose(conv5, 128, [2, 1], [2, 1], padding='same', activation=tf.nn.relu, kernel_initializer=init, name='conv6')

conv7 = tf.layers.conv2d_transpose(conv6, 64, [2, 1], [2, 1], padding='same', activation=tf.nn.relu, kernel_initializer=init, name='conv7')

# Output
y_out = tf.layers.conv2d(conv7, 1, [1, 2], padding='valid', kernel_initializer=init, name='conv8')
y = tf.squeeze(y_out)

# Cross-entropy loss and optimizer
avg_loss = tf.reduce_mean(tf.reduce_sum(tf.abs(tf.subtract(y, y_)), reduction_indices=[1]))
lambda_param = 2.0
cost = avg_loss + lambda_param * tf.reduce_mean(pl_weights_round)
train_step = tf.train.AdamOptimizer(learning_rate=1e-3).minimize(cost)

training_loss = []
valid_loss = []
chrono = []

# Create a Session object, initialize all variables
with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    sess.run(train_iterator.initializer)
    sess.run(validation_iterator.initializer)
    sess.run(test_iterator.initializer)

    # Add ops to save and restore all the variables.
    saver = tf.train.Saver()

    tic = time.perf_counter()

    # Train
    for iter in range(10000):
        batch_xs, batch_ys = sess.run(next_train)
        sess.run(train_step, feed_dict={x: batch_xs, y_: batch_ys})
 
        # Evaluation
        if iter % 250 == 0:
            batch_xs, batch_ys = sess.run(next_train)
            training_loss.append(sess.run(avg_loss, feed_dict={x: batch_xs, y_: batch_ys}))

            batch_xs, batch_ys = sess.run(next_validation)
            valid_loss.append(sess.run(avg_loss, feed_dict={x: batch_xs, y_: batch_ys}))
            
            chrono.append(time.perf_counter() - tic)

            print('Iteration: {0}, validation loss: {1}\n'.format(iter, valid_loss[-1]/1200))

    batch_xs, batch_ys = sess.run(next_test)
    pred = sess.run(y, feed_dict={x: batch_xs, y_: batch_ys})
    scipy.io.savemat('/work/dyc6/dispnn/results_physical.mat', mdict={'true': batch_ys, 'pred': pred, 'training_loss': training_loss, 'valid_loss': valid_loss, 'time': chrono, 'batch_xs': batch_xs})

    save_path = saver.save(sess, 'tmp_physical/model.ckpt', write_meta_graph=False)
    print('Model saved in path: %s' % save_path)
    print(np.sum(sess.run(pl_weights_round)))
