function iqcompile(seed)

addpath('ultratrack/')
%seed2 = seed;
for i = 0:29
seed2 = seed + i*1000;
disp(['processing seed ' num2str(seed2)])

folder1 = ['phantom_sym_none_N_110880_seed_' num2str(seed2) '_rand_scat_amp_1_delta_0_0_0_X_-1_1_Y_-3.5_3.5_Z_0.5_50'];
folder2 = 'rf_PROBE_12L4_c_1540_APEX_0_TX_FOCUS_60_TX_F_NUM_3_1_TX_FREQ_5_TX_NUM_CYCLES_2_RX_FOCUS_0_RX_F_NUM_0.5_1_RX_GROW_APERTURE_1_MINDB_NaN_X_0_0_0_Y_0_0_0_PHI_0_0_0_THETA_0_0_0_NO_BEAMS_1_1_NPAR_1_1_PSPACE_1_1_FS_1000';

rf1 = load(['scratch/' folder1 '/' folder2 '/rf001.mat']);
rf2 = load(['scratch/' folder1 '/' folder2 '/rf002.mat']);

min_rf_length = min(length(rf1.rf), length(rf2.rf));

rf1_crop = rf1.rf(1:min_rf_length);
rf2_crop = rf2.rf(1:min_rf_length);

par = load('parameters.mat');

t = 1/(1e9).*(0:min_rf_length-1)*1e6; % us
axial = (0:min_rf_length-1) * 1540 * 1e3 / (2*1e9); % mm

demodRange = par.Apl3.Mod.DsF.rr;
demodFreqOrig = par.Apl3.Mod.DsF.data;
demodFreq = interp1(demodRange,demodFreqOrig,axial,'linear'); % MHz

ri1 = rf1_crop .* cos(2.*pi.*demodFreq.*t)';
rq1 = rf1_crop .* sin(2.*pi.*demodFreq.*t)';
ri2 = rf2_crop .* cos(2.*pi.*demodFreq.*t)';
rq2 = rf2_crop .* sin(2.*pi.*demodFreq.*t)';

ri1_filt = lpf(ri1, 1e9, 5e6, 6);
rq1_filt = lpf(rq1, 1e9, 5e6, 6);
ri2_filt = lpf(ri2, 1e9, 5e6, 6);
rq2_filt = lpf(rq2, 1e9, 5e6, 6);

I1 = 2*ri1_filt;
Q1 = -2*rq1_filt;
I2 = 2*ri2_filt;
Q2 = -2*rq2_filt;

desired_fs = 5e6; % Hz
downfactor = floor(1e9 / desired_fs);

actual_fs = 1e9 / downfactor;

I1_down = I1(1:downfactor:end);
Q1_down = Q1(1:downfactor:end);
I2_down = I2(1:downfactor:end);
Q2_down = Q2(1:downfactor:end);

upsampleAgain = 1;

if upsampleAgain
    upsampleFactor = 5;
    ndepths = length(I1_down);
    nup = ndepths*upsampleFactor;
    x = 0:(ndepths-1);
    xi = (0:(nup-1))/upsampleFactor;
    I1_up = upsampleSplineSevalMatlab(ndepths,x,I1_down,xi);
    Q1_up = upsampleSplineSevalMatlab(ndepths,x,Q1_down,xi);
    I2_up = upsampleSplineSevalMatlab(ndepths,x,I2_down,xi);
    Q2_up = upsampleSplineSevalMatlab(ndepths,x,Q2_down,xi);
end

time = (0:length(I1_up)-1) / (actual_fs*upsampleFactor);
%[ir, t0] = makeImpulseResponse(0.768, 7120000, 1e9);
depth_cm = time * 1540 * 1e2 / 2;

%I1_out = I1_up(depth_cm >= 0.1 & depth_cm <= 5);
%Q1_out = Q1_up(depth_cm >= 0.1 & depth_cm <= 5);
%I2_out = I2_up(depth_cm >= 0.1 & depth_cm <= 5);
%Q2_out = Q2_up(depth_cm >= 0.1 & depth_cm <= 5);

%depth_out = depth_cm(depth_cm >= 0.1 & depth_cm <= 5);

max_idx = find(depth_cm <= 3.5, 1, 'last');
%idx = max_idx-1199:max_idx;
idx = 1:1200;

I1_out = I1_up(idx);
Q1_out = Q1_up(idx);
I2_out = I2_up(idx);
Q2_out = Q2_up(idx);

depth_out = depth_cm(idx);

iqdata = [I1_out, Q1_out, I2_out, Q2_out];

dispdata = load(['scratch/dispdata/zdisp_' num2str(seed2) '.mat']);
v = squeeze(dispdata.displacements(21,71, :, 2));

x = linspace(0, 50, 1001)/10; % simulated depth in cm

truedisp = interpn(x, v, depth_out, 'linear')';

if size(iqdata,1) ~= 1200 || size(iqdata,2) ~= 4 || length(truedisp) ~= 1200
    disp('SOMETHING WENT WRONG!')
    return
end

save(['scratch/trackdata_iq_shallow/data' num2str(seed2) '.mat'], 'iqdata', 'truedisp', '-v7.3')

end
disp('done')

end
