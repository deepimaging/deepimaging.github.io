function out = lpf(data, fs, cutoff, order)
% out = lpf(data, fs, cutoff)
%
% Inputs: data = data to be filtered
%         fs = sampling frequency (Hz)
%         cutoff = cutoff frequency (Hz)
%         order = filter order (integer > 0)
%
% Output: out = filtered data
%
% Creates a low-pass Butterworth filter at the cutoff frequency and then
% runs the filtfilt command to perform the filtering so that there is no
% phase lag

[B, A] = butter(order, cutoff/(fs/2));
out = filtfilt(B, A, double(data));