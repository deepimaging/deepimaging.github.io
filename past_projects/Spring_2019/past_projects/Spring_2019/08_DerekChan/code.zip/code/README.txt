# BME 590 Final Project Code

`physical_layer.py` contains the TensorFlow code that includes the neural network architecture, physical layer, and training sequences. MATLAB code used to generate the training data are included in the .m files. 
