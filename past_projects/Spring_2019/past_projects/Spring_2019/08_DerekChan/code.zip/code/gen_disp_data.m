function generate_disp_data(seed)

for i = 0:29
    disp(['processing ' num2str(i+1) ' of 30'])
    seed2 = seed + i*1000;
    rng(seed2)

    numEllipses = 150;
    maxDisp = 1.5;
    ellipseParams = zeros(numEllipses, 10);

    ellipseParams(:, 1) = (rand(numEllipses, 1) - 0.45) * 2 * maxDisp;
    ellipseParams(:, 2) = rand(numEllipses, 1) * 0.75;
    ellipseParams(:, 3) = rand(numEllipses, 1) * 0.75;
    ellipseParams(:, 4) = rand(numEllipses, 1) * 0.75;
    ellipseParams(:, 5) = (rand(numEllipses, 1) - 0.5) * 0.2;
    ellipseParams(:, 6) = (rand(numEllipses, 1) - 0.5) * 0.7;
    ellipseParams(:, 7) = (rand(numEllipses, 1) - 0.5) * 4;
    ellipseParams(:, 8) = rand(numEllipses, 1) * 360;
    ellipseParams(:, 9) = rand(numEllipses, 1) * 360;
    ellipseParams(:, 10) = rand(numEllipses, 1) * 360;

    axialmm = linspace(0, 40, 801);
    elevmm = linspace(-3.5, 3.5, 141);
    latmm = linspace(-1, 1, 41);
    tms = [0, 1];

    p = imgaussfilt3(phantom3d(latmm, elevmm, axialmm, ellipseParams),3);
    displacements = zeros(41,141,801,2);
    displacements(:,:,:,2) = p;

    tms = [0, 1];

    savefile = ['/work/dyc6/dispnn/scratch/dispdata_shallow/zdisp_' num2str(seed2)];
    save(savefile, 'displacements', 'axialmm', 'elevmm', 'latmm', 'tms', '-v7.3');
end

end

