function driver(phantom_seed)
% function driver(phantom_seed, nodes, dispdat)
% INPUTS:
%   phantom_seed (int) - scatterer position RNG seed
%   nodes (string) - location of nodes.dyn (comma-delimited); must be absolute
%                    or explicitely relative
%   dispdat (string) - location of disp.dat (where phantom* results will be
%                      saved); must be absolute or explicitely relative
%
% OUTPUTS:
%   Nothing returned, but lots of files and directories created in the parent
%   directory of disp.
%
% EXAMPLE: driver(0, './nodes.dyn', './disp.dat')
%

% ------------------PHANTOM PARAMETERS----------------------------
% setup phantom parameters (PPARAMS)
% leave any empty to use mesh limit
generatephantom = true;
PPARAMS.sym = 'none'; % 'q', 'h', 'none'
PPARAMS.xmin=[-0.35];PPARAMS.xmax=[0.35];	% out-of-plane,cm
PPARAMS.ymin=[-0.1];PPARAMS.ymax=[0.1];	% lateral, cm \
PPARAMS.zmin=[-4.0];PPARAMS.zmax=[-0.05];% axial, cm   / X,Y SWAPPED vs FIELD!
% Timesteps to simulate (leave empty for all timesteps)
PPARAMS.TIMESTEP=[];

% compute number of scatterers to use
SCATTERER_DENSITY = 160000; % scatterers/cm^3
PPARAMS.N = calc_n_scats(SCATTERER_DENSITY, PPARAMS);

PPARAMS.seed=phantom_seed;         % RNG seed

% amplitude of the randomly-distributed scatterers 
% (set to 0 if you just want the point scatterers defined below)
PPARAMS.rand_scat_amp = 1;

% rigid pre-zdisp-displacement scatterer translation, in the dyna
% coordinate/unit system to simulate ARFI sequences with multiple runs
PPARAMS.delta=[0 0 0];

%% MAP DISPLACEMENTS TO SCATTERER FIELD & GENERATE PHANTOMS
zdispmat = ['scratch/dispdata_shallow/zdisp_' num2str(phantom_seed) '.mat']; 
PHANTOM_DIR=[make_file_name('phantom', [fileparts(zdispmat) '/../phantom'], PPARAMS) '/'];
PHANTOM_FILE=[PHANTOM_DIR 'phantom'];
d = dir([PHANTOM_FILE '*.mat']);
if isempty(d) || generatephantom
    mkdir(PHANTOM_DIR);
    mkphantomfromdisp(zdispmat, PHANTOM_FILE, PPARAMS);
end

%  --------------IMAGING PARAMETERS---------------------------------
PARAMS.PROBE ='12L4';
PARAMS.COMPUTATIONMETHOD = 'dcc'; % 'cluster','parfor', or 'none'

% setup some Field II parameters
PARAMS.field_sample_freq = 1e9; % Hz
PARAMS.c = 1540; % sound speed (m/s)

% TRACKING BEAM PARAMETERS
PARAMS.XMIN=    0;              % Leftmost scan line (m)
PARAMS.XSTEP =  0;         % Azimuth step size (m);
PARAMS.XMAX=    0;	        % Rightmost scan line (m)
PARAMS.THMIN =  0;              % Leftmost azimuth angle (deg)
PARAMS.THSTEP = 0;              % Azimuth angle step(deg)
PARAMS.THMAX =  0;              % Rightmost azimuth angle (deg)
PARAMS.PHIMIN= 0;               % Frontmost elevation angle (deg)
PARAMS.PHISTEP = 0;             % Elevation angle step(deg)
PARAMS.PHIMAX= 0;               % Backmost elevation angle (deg)
PARAMS.YMIN=   0;		        % Frontmost scan line (m)
PARAMS.YSTEP = 0;               % Elevation step size (m)
PARAMS.YMAX=   0;	            % Backmost scan line (m)
PARAMS.APEX = 0;                % Apex of scan geometry; 0 for linear scanning
PARAMS.TX_FOCUS= 60.0e-3;       % Tramsmit focus depth (m)
PARAMS.TX_F_NUM=[3 1];          % Tx F/# (index 2 only used for 2D matrix arrays)
PARAMS.TX_FREQ=5e6;          % Transmit frequency (Hz)
PARAMS.TX_NUM_CYCLES=2;         % Number of cycles in transmit toneburst
PARAMS.RX_FOCUS= 0;             % Depth of receive focus - use 0 for dynamic Rx
PARAMS.RX_F_NUM=[0.5 1];          % Rx F/# (index 2 only used for 2D matrix arrays)
PARAMS.RX_GROW_APERTURE=1;      
PARAMS.MINDB = NaN;             % Min dB to include a scat in reduction (NaN to disable)
PARAMS.NO_PARALLEL = [1 1];     % [no_X no_Y]
PARAMS.PARALLEL_SPACING = [1 1]; % Spread || RX Beams Multiplier [X Y]

PARAMS = parallel_tx_rx(0, 0, PARAMS); % Tx & Rx beam override possible with 1s

%% ------------- GENERATE RF SCANS OF SCATTERER FIELDS -------------------
RF_DIR=[make_file_name('rf', [PHANTOM_DIR 'rf'], PARAMS) '/'];
RF_FILE=[RF_DIR 'rf'];
mkdir(RF_DIR);
field_init(-1);

% set attenuation
alpha_dB_cm_MHz = 0.5;
Freq_att = alpha_dB_cm_MHz*100/1e6;
att_f0 = 5e6;
att = Freq_att*att_f0;
set_field('att', att);
set_field('Freq_att', Freq_att);
set_field('att_f0', att_f0);
set_field('use_att', 1);

do_dyna_scans(PHANTOM_FILE, RF_FILE, PARAMS);
field_end;
