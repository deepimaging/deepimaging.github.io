train_n = 26000;
validation_n = 2000;
test_n = 2000;

z_dim = 1200;

train_images = zeros(train_n, z_dim, 2, 2);
train_labels = zeros(train_n, z_dim);

validation_images = zeros(validation_n, z_dim, 2, 2);
validation_labels = zeros(validation_n, z_dim);

test_images = zeros(test_n, z_dim, 2, 2);
test_labels = zeros(test_n, z_dim);

disp('loading training data')

for i = 1:train_n
    data = load(['scratch/trackdata_iq_shallow/data' num2str(i) '.mat']);
    train_images(i, :, 1, :) = single(data.iqdata(:, 1:2));
    train_images(i, :, 2, :) = single(data.iqdata(:, 3:4));
    train_labels(i, :) = single(data.truedisp);
end

disp('loading validation data')

for i = 1:validation_n
    data = load(['scratch/trackdata_iq_shallow/data' num2str(train_n+i) '.mat']);
    validation_images(i, :, 1, :) = single(data.iqdata(:, 1:2));
    validation_images(i, :, 2, :) = single(data.iqdata(:, 3:4));
    validation_labels(i, :) = single(data.truedisp);
end

disp('loading test data')

for i = 1:test_n
    data = load(['scratch/trackdata_iq_shallow/data' num2str(train_n+validation_n+i) '.mat']);
    test_images(i, :, 1, :) = single(data.iqdata(:, 1:2));
    test_images(i, :, 2, :) = single(data.iqdata(:, 3:4));
    test_labels(i, :) = single(data.truedisp);
end

% NORMALIZE DATA...
% calculate mean and standard deviation every feature in entire training set
train_mean = mean(train_images, 1);
train_std = std(train_images, 0, 1);

% normalize all by the same mean and std
train_images = (train_images - train_mean) ./ train_std;
validation_images = (validation_images - train_mean) ./ train_std;
test_images = (test_images - train_mean) ./ train_std;

% save normalization data for future test cases
%save('norm.mat', 'train_mean', 'train_std', '-v7.3')

disp('saving data')

fname = 'iq_data_shallow.h5';

delete iq_data_shallow.h5
h5create(fname, '/train_images', [2 2 z_dim train_n]);
h5write(fname, '/train_images', permute(train_images,[4 3 2 1]));
h5create(fname, '/train_labels', [z_dim train_n]);
h5write(fname, '/train_labels', train_labels');

h5create(fname, '/validation_images', [2 2 z_dim validation_n]);
h5write(fname, '/validation_images', permute(validation_images,[4 3 2 1]));
h5create(fname, '/validation_labels', [z_dim validation_n]);
h5write(fname, '/validation_labels', validation_labels');

h5create(fname, '/test_images', [2 2 z_dim test_n]);
h5write(fname, '/test_images', permute(test_images,[4 3 2 1]));
h5create(fname, '/test_labels', [z_dim test_n]);
h5write(fname, '/test_labels', test_labels');
