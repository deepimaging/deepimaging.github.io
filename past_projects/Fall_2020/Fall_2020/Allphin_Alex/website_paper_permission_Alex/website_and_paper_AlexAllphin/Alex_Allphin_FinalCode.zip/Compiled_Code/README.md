# Code Information:
I have provided code from the following categories (unfortunately I will not be providing the raw training data):
1. Data Simulations/Preparation
2. Training Models and Scripts
3. A Jupyter Notebook with a large portion of work, that ended up not yielding great results but probably is the most interesting and took the most time.

## Notes on file formats:
Python files I typically run in the console so that I can debug more than in a jupyter notebook. I apologize that by nature there are no outputs saved with those files.
Seeing that you don't have the files, you won't be able to run those. I am willing to answer any questions you may have about their contents.

The Jupyter file has outputs available. But I was unfortunately never able to run everything.
